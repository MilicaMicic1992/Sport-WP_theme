      <!-- footer -->
      <footer>
         <div class="footer">
            <div class="container">
               <div class="row">
                  <div class="col-md-8 offset-md-2">
                     <h3>Follow Us</h3>
                     <ul class="social_icon text_align_center">
                        <li> <a href="Javascript:void(0)"><i class="fa fa-facebook-f"></i></a></li>
                        <li> <a href="Javascript:void(0)"><i class="fa fa-twitter"></i></a></li>
                        <li> <a href="Javascript:void(0)"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li> <a href="Javascript:void(0)"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                        <li> <a href="Javascript:void(0)"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                     </ul>
                     <div class="conta text_align_center">
                        <ul>
                           <li> 
                              <a href="Javascript:void(0)">
                                 <img src="<?php echo get_template_directory_uri();?>/img/call.png" alt="#"/>
                                  Call 
                                  <?php $phone = get_field('phone', 'option');
                                    echo $phone;
                                 ?>

                              </a>
                           </li>
                           <li> 
                              <a href="Javascript:void(0)"><img src="<?php echo get_template_directory_uri();?>/img/mall.png" alt="#"/>
                                 <?php $email = get_field('email', 'option');
                                  echo $email;
                                  ?>
                              </a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-8 offset-md-2">
                     <div class="menu_bottom text_align_center">
                     <?php
            $menu_args = array(
                  'theme_location'  => 'sport_menu'     
                  );
               wp_nav_menu($menu_args);
          
         ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="copyright text_align_center">
               <div class="container">
                  <div class="row">
                     <div class="col-md-8 offset-md-2">
                        <p>
                        &copy; <?php echo date('Y');?>
                          <?php
                            $footer_description = get_field('footer_description', 'option');
                           echo $footer_description;
                          ?> 
                           <a href="https://html.design/"> 
                              Free Html Template
                           </a>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- end footer -->


      <?php wp_footer(); ?>
   </body>
</html>