<?php
//////Iskljucivanje Gutenberg editora//////

    add_filter('use_block_editor_for_post', '__return_false', 10);


//////Ukljucivanje CSS i JS//////

// Install jQuery 3.4.1 - jQuery CDN
function vpsb_custom_jquery() {

    // obrisi default jquery koji wp ubacuje sam
    wp_deregister_script('jquery');
    wp_register_script('jquery', ("https://code.jquery.com/jquery-3.4.1.min.js"), false);
    wp_enqueue_script('jquery');
    }
add_action('wp_enqueue_scripts', 'vpsb_custom_jquery');

function enqueue_custom_styles_and_scripts() {
    $theme_version = wp_get_theme()->get('Version');
    $css_directory = get_template_directory_uri() . '/assets/css/';
    $js_directory = get_template_directory_uri() . '/assets/js/';
   
    // Enqueue CSS Libraries
    wp_enqueue_style( 'style', get_stylesheet_uri(), array(), $theme_version, 'all' );
    wp_enqueue_style('bootstrap-milica', $css_directory . 'bootstrap.min.css', array(), $theme_version);
    wp_enqueue_style('font-awesome', $css_directory . 'font-awesome.min.css', array(), $theme_version);
    wp_enqueue_style('responsive', $css_directory . 'responsive.css', array(), $theme_version);
    
    wp_enqueue_script('bootstrap-milica', $js_directory . 'bootstrap.js', array(), '2.6.12', true);
    wp_enqueue_script('custom-scroll-bar', $js_directory . 'jquery.mCustomScrollbar.concat.min.js', array(), '1.8.2', true);
    wp_enqueue_script('owl', $js_directory . 'owl.carousel.min.js', array(), '4.17.21', true);
    wp_enqueue_script('custom', $js_directory . 'custom.js', array(), '16.14.0', true);
}

add_action('wp_enqueue_scripts', 'enqueue_custom_styles_and_scripts');





/*
function enqueue_custom_styles_and_scripts() {
    $theme_version = wp_get_theme()->get('Version');
    $css_directory = get_template_directory_uri() . '/assets/css/';
    $js_directory = get_template_directory_uri() . '/assets/js/';
   
    wp_enqueue_style( 'style', get_stylesheet_uri(), array(), $theme_version, 'all' );
    wp_enqueue_style('bootstrap-milica', $css_directory . 'bootstrap.min.css', array(), $theme_version);
    wp_enqueue_style('font-awesome', $css_directory . 'font-awesome.min.css', array(), $theme_version);
    wp_enqueue_style('owl', $css_directory . 'owl.carousel.min.css', array(), $theme_version);


    wp_enqueue_script('bootstrap-milica', $js_directory . 'bootstrap.js', array(), '2.6.12', true);
    wp_enqueue_script('custom-scroll-bar', $js_directory . 'jquery.mCustomScrollbar.concat.min.js', array(), '1.8.2', true);
    wp_enqueue_script('owl', $js_directory . 'owl.carousel.min.js', array(), 'v2.3.4', true);
    wp_enqueue_script('custom', $js_directory . 'custom.js', array(), '16.14.0', true);
}

add_action('wp_enqueue_scripts', 'enqueue_custom_styles_and_scripts');
*/
 
//////Ubacivanje menija na sajt//////

    register_nav_menus( array(
        'sport_menu' => 'Main Manu'
    ) );

//////Registrovanje Theme setings//////

    if( function_exists('acf_add_options_page') ) {
        
        if( function_exists('acf_add_options_page') ) {
        
            acf_add_options_page(array(
                'page_title'    => 'Theme General Settings',
                'menu_title'    => 'Theme Settings',
                'menu_slug'     => 'theme-general-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ));
        
        }
    }


    
    // Register Custom Post Type
function clanovi_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Clanovi', 'Post Type General Name', 'sport' ),
		'singular_name'         => _x( 'Clan', 'Post Type Singular Name', 'sport' ),
		'menu_name'             => __( 'Clanovi', 'sport' ),
		'name_admin_bar'        => __( 'Post Type', 'sport' ),
		'archives'              => __( 'Item Archives', 'sport' ),
		'attributes'            => __( 'Item Attributes', 'sport' ),
		'parent_item_colon'     => __( 'Parent Item:', 'sport' ),
		'all_items'             => __( 'All Items', 'sport' ),
		'add_new_item'          => __( 'Add New Item', 'sport' ),
		'add_new'               => __( 'Add New', 'sport' ),
		'new_item'              => __( 'New Item', 'sport' ),
		'edit_item'             => __( 'Edit Item', 'sport' ),
		'update_item'           => __( 'Update Item', 'sport' ),
		'view_item'             => __( 'View Item', 'sport' ),
		'view_items'            => __( 'View Items', 'sport' ),
		'search_items'          => __( 'Search Item', 'sport' ),
		'not_found'             => __( 'Not found', 'sport' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'sport' ),
		'featured_image'        => __( 'Featured Image', 'sport' ),
		'set_featured_image'    => __( 'Set featured image', 'sport' ),
		'remove_featured_image' => __( 'Remove featured image', 'sport' ),
		'use_featured_image'    => __( 'Use as featured image', 'sport' ),
		'insert_into_item'      => __( 'Insert into item', 'sport' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'sport' ),
		'items_list'            => __( 'Items list', 'sport' ),
		'items_list_navigation' => __( 'Items list navigation', 'sport' ),
		'filter_items_list'     => __( 'Filter items list', 'sport' ),
	);
	$args = array(
		'label'                 => __( 'Clan', 'sport' ),
		'description'           => __( 'Custom post za clanove', 'sport' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'clan_post', $args );

}
add_action( 'init', 'clanovi_custom_post_type', 0 );

// Register Custom Post Type za proizvode
function proizvodi_custom_post_type() {

	$labels = array(
		'name'                  => _x( 'Proizvod', 'Post Type General Name', 'sport' ),
		'singular_name'         => _x( 'Proizvodi', 'Post Type Singular Name', 'sport' ),
		'menu_name'             => __( 'Proizvodi', 'sport' ),
		'name_admin_bar'        => __( 'Post Type', 'sport' ),
		'archives'              => __( 'Item Archives', 'sport' ),
		'attributes'            => __( 'Item Attributes', 'sport' ),
		'parent_item_colon'     => __( 'Parent Item:', 'sport' ),
		'all_items'             => __( 'All Items', 'sport' ),
		'add_new_item'          => __( 'Add New Item', 'sport' ),
		'add_new'               => __( 'Add New', 'sport' ),
		'new_item'              => __( 'New Item', 'sport' ),
		'edit_item'             => __( 'Edit Item', 'sport' ),
		'update_item'           => __( 'Update Item', 'sport' ),
		'view_item'             => __( 'View Item', 'sport' ),
		'view_items'            => __( 'View Items', 'sport' ),
		'search_items'          => __( 'Search Item', 'sport' ),
		'not_found'             => __( 'Not found', 'sport' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'sport' ),
		'featured_image'        => __( 'Featured Image', 'sport' ),
		'set_featured_image'    => __( 'Set featured image', 'sport' ),
		'remove_featured_image' => __( 'Remove featured image', 'sport' ),
		'use_featured_image'    => __( 'Use as featured image', 'sport' ),
		'insert_into_item'      => __( 'Insert into item', 'sport' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'sport' ),
		'items_list'            => __( 'Items list', 'sport' ),
		'items_list_navigation' => __( 'Items list navigation', 'sport' ),
		'filter_items_list'     => __( 'Filter items list', 'sport' ),
	);
	$args = array(
		'label'                 => __( 'Proizvodi', 'sport' ),
		'description'           => __( 'Proizvodi', 'sport' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 7,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'proizvodi_post', $args );

}
add_action( 'init', 'proizvodi_custom_post_type', 0 );