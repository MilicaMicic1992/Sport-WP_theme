<!--
 **********************************************
 * Project: Sport news
 **********************************************
 * Developed by: MIlica Micic
   + design: 
   + e-mail: <milica.maksimovic0922@gmail.com>
   + html, css, vanilla js & php
   + responsive page
 *********************************************
-->

<!DOCTYPE html>
<html <?php language_attributes ();?>>
   <head>
      <!-- basic -->
      <meta charset="<?php bloginfo(' charset '); ?>">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title><?php wp_title();?> </title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
   
      
      <?php wp_head(); ?>
   </head>
   <!-- body -->
   <body class="main-layout" <?php body_class();?>>
      <!-- loader  -->
      <!--<div class="loader_bg">
         <div class="loader"><img src="/img/loading.gif" alt="" /></div>
      </div>-->
      <!-- end loader -->
      <div id="mySidepanel" class="sidepanel">
         <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">x</a>
         <?php
            $menu_args = array(
                  'theme_location'  => 'sport_menu'      
                  );
               wp_nav_menu($menu_args);
         ?>
      </div>
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="head-top">
            <div class="container-fluid">
               <div class="row d_flex">
                  <div class="col-sm-3">
                     <div class="logo">
                        <a href="<?php echo home_url();?>">
                        <?php 
                           $logo = get_field('logo', 'option');
                        ?>
                        <img src="<?php echo $logo['url']?>"
                             alt="<?php echo $logo['alt']?>">
                        </a>
                     </div>
                  </div>
                  <div class="col-sm-9">
                     <ul class="email text_align_right">
                        <li><a href="Javascript:void(0)"><i class="fa fa-user" aria-hidden="true"></i></a></li>
                        <li><a href="Javascript:void(0)"><i class="fa fa-search" aria-hidden="true"></i></a></li>
                        <li> <button class="openbtn" onclick="openNav()"><img src="<?php echo get_template_directory_uri();?>/img/menu_btn.png"></button></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- end header -->