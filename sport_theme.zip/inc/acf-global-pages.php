
<?php

if (have_rows('flexible_content_field')) : ?>
    <?php while (have_rows('flexible_content_field')) : the_row(); ?>

        <?php if (get_row_layout() == 'text_section') : ?>
            <?php
            $text = esc_html(get_sub_field('text'));
            $alignment = esc_attr(get_sub_field('alignment'));
            ?>

            <div class="text-section <?php echo $alignment; ?>">
                <?php echo $text; ?>
            </div>

        <?php elseif (get_row_layout() == 'image_section') : ?>
            <?php
            $image = get_sub_field('image');
            $caption = esc_html(get_sub_field('caption'));
            ?>

            <div class="image-section">
                <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                <?php if ($caption) : ?>
                    <div class="caption"><?php echo $caption; ?></div>
                <?php endif; ?>
            </div>

        <?php elseif (get_row_layout() == 'video_section') : ?>
            <?php
            $video_url = esc_url(get_sub_field('video_url'));
            $autoplay = esc_attr(get_sub_field('autoplay'));
            ?>

            <div class="video-section">
                <video <?php if ($autoplay) echo 'autoplay'; ?> controls>
                    <source src="<?php echo $video_url; ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>


            <?php elseif (get_row_layout() == 'services') : ?>
                <section class="services" role="region" aria-label="Naše usluge">
                    <!-- Start of services section -->
                    <div class="container">
                        <!-- Start container -->
                        <h2 class="page-title">Naše usluge</h2>
                        <div class="services-body">
                            <!-- Services items -->
                            <?php if (have_rows('services')) : ?>
                                <?php while (have_rows('services')) : the_row(); ?>
                                    <div class="services-item">
                                        <img src="<?php echo esc_url(get_sub_field('image')); ?>" alt="">
                                        <h6><?php echo esc_html(get_sub_field('title')); ?></h6>
                                        <p><?php echo esc_html(get_sub_field('description')); ?></p>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- End container -->
                </section>
                <!-- End of services section -->


        <?php endif; ?>

    <?php endwhile; ?>
<?php endif; ?>
