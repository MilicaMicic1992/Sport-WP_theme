<?php
/*
Template name: Home page
*/ 
get_header();
?>


<?php if ( have_rows('milica') ) : ?>
   <div class="footbol">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-12">
                  <div id="myCarousel" class="carousel slide" data-ride="carousel">
                     <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                     </ol>
                     <div class="carousel-inner">
   <?php while( have_rows('milica') ) : the_row(); ?>

  
      <div class="carousel-item">
                           <div class="container-fluid">
                              <div class="carousel-caption relative">
                                 <div class="bluid">
                                    <div class="foot_img">
                                    <figure>
                                       <img src="<?php the_sub_field('milica_subfield'); ?>" alt="#"/>
                                    </figure>
                                    </div>
                                    <a class="read_more" href="Javascript:void(0)">Read More </a>
                                 </div>
                              </div>
                           </div>
                        </div>
   <?php endwhile; ?>
   </div>
                     <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                     <i class="fa fa-angle-left" aria-hidden="true"></i>
                     <span class="sr-only">Previous</span>
                     </a>
                     <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                     <i class="fa fa-angle-right" aria-hidden="true"></i>
                     <span class="sr-only">Next</span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- sports -->
<?php endif; ?>

<!-- footbol section -->


   


<?php get_footer();?>