<?php
get_header();
?>

Ovo je milicin custom post clanovi. Ovde unosi varijable koje sam malo pre napravila u custom post templateu


Ovaj template povezujem sa ACF tako sto u donjem levom cosku izaberem post type i sa desne strane izaberem iz select liste post koji sam napravila. U nasem slucaju custo post clan_post 


VAZNO NAJVAZNIJE : 
kad god kreiram custom post moram da uradim save permalinks. Gsettings- permalinks-save


Napomena : kada kreinram custom post u rootu teme treba da napravim fajl koji se zove single-[ovde unosim ime posta koji sam registrovala].
(register_post_type( 'clan_post'!!!, $args );)


<?php the_field('slika');
?>


<?php
get_footer();
?>