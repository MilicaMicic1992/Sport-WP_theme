<?php
get_header();
?>


<img src="<?php the_field('slika');?>" alt="">

<p><?php the_field('tekst');?></p>



<?php
get_footer();
?>