<?php
get_header();
?>



<?php
the_title();
?>

sve sto se nalazi u dashaboardu u posts se nalazi u ovom template

<?php the_field('strahinja');?>


<?php
get_footer();
?>



